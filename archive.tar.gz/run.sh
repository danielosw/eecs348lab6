#!/bin/sh
python3 -m http.server -b 127.0.0.42 8080
